import FaucetScreen from "../screens/FaucetScreen";

export default function FaucetRoute() {
  return <FaucetScreen />;
}
