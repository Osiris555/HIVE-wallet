export async function getHoneyBalance(): Promise<number> {
  // TEMPORARY MOCK VALUE
  return 12345.678;
}
