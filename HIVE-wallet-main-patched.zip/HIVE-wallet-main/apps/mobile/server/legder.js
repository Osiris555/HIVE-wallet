export const balances = {};
export const transactions = [];
